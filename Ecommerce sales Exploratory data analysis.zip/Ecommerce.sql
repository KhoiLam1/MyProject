Select Count(distinct CustomerID) from OnlineRetail1
--New customer


select CustomerID, min(InvoiceDate) as FirstOrderDate
from OnlineRetail1 o
group by CustomerID;

select year(FirstOrderDate) as yr, month(FirstOrderDate) as mon, count(*) as number_of_customers
from (select CustomerID, min(InvoiceDate) as FirstOrderDate from OnlineRetail1 group by CustomerID
    ) oc
group by year(FirstOrderDate), month(FirstOrderDate)
order by year(FirstOrderDate), month(FirstOrderDate)

--Repeat customer

SELECT CustomerID FROM OnlineRetail1
GROUP BY CustomerID
HAVING COUNT(*) > 1)
GROUP BY YEAR(InvoiceDate),MONTH(InvoiceDate);

--Churn 
SELECT YEAR(this_month.InvoiceDate) as year_date,MONTH(this_month.InvoiceDate) as month_date, COUNT(distinct last_month.CustomerID) as Amount FROM
OnlineRetail1 this_month
left join OnlineRetail1 last_month
on this_month.CustomerID = last_month.CustomerID and DATEDIFF(MONTH,last_month.InvoiceDate,this_month.InvoiceDate) = 1
group by YEAR(this_month.InvoiceDate),Month(this_month.InvoiceDate)



